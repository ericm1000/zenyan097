use strict;
# Bit Manipulation

my $val;

# A Nibble
#      8 4 2 1
#      -------
#      1 0 0 1 = decimal 9
#      1 0 1 0 = decimal 10
#      -------

#      8 4 2 1
#      -------
# AND  1 0 0 0
# 8
$val = 9 & 10;
print ($val,"\n");

#      8 4 2 1
#      -------
# OR   1 0 1 1    
# 11
$val = 9 | 10;
print ($val,"\n");

#      8 4 2 1
#      -------
# XOR  0 0 1 1
# 3
$val = 9 ^ 10;
print ($val,"\n");

#      8 4 2 1
#      -------
#      1 1 1 1  Shift Right
#      0 1 1 1 
$val = 15;
$val = $val >> 1;
print ($val,"\n");

#   16 8 4 2 1
#   ----------
#      1 1 1 1  Shift Left
#    1 1 1 1 
$val = 15;
$val = $val << 1;
print ($val,"\n");
# $val = 30 , remember number is 32-bit and we shifted left

# NOT
# Number is a 32-bit number
$val = ~4294967292;
print ($val,"\n");
$val = ~3;
print ($val,"\n");



