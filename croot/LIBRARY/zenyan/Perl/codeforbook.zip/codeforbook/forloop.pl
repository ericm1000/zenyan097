use strict;
my $i;
for ($i = 1; $i <= 10; ++$i)
{
print "$i, ";
}
