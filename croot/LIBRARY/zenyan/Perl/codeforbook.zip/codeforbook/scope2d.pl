use strict;  

&mysub;

sub mysub {
   my $i=9;
   print ("sub \$i: ",$i,"\n");
   &mysub2($i);
}


sub mysub2 {
   my $x = shift(@_);
   print ("sub \$x: ",$x,"\n");
}