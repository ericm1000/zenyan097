use strict;

my $tf=1; # 0 is false 1 is true
my $i=0;

while ($tf) {
  if ($i == 10) {
     $tf = 0;
  } else {
          $i++;
          print ($i," ");
    }
}

print "\n";

my $var;
if ($var) {
	print "initialized\n";
} else {
	print "not initialized\n";
  }

my $var = "some value";
if ($var) {
	print "initialized\n";
} else {
	print "not initialized\n";
  }