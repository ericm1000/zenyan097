use strict;
my @i = (1, 5, "foo", "end");

&mysub(@i);

sub mysub
{
  foreach (@_)
  {
    print "$_\n";
  }
}

