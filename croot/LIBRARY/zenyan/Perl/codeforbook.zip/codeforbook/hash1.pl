use strict;

# create an empty hash
my %hsh = ();

#add some elements
$hsh{'firstname'} = 'John';
$hsh{'middle_init'} = 'H.';
$hsh{'lastname'} = 'Smith';

print $hsh{lastname};

