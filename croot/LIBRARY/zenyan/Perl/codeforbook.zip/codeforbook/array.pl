use strict;

my @x;   #an empty array
my @y = ();   #an empty array
my @z = ("a","b","c",1,2,"3",1+3,"1"+"3");


print (@x,"\n",@y,"\n",@z);
