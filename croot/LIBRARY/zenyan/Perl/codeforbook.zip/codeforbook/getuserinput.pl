use strict;

my $mystr = <STDIN>; #wait for user to type something in
print $mystr;        #echo back to console what they typed



