use strict;

my $a=5;
my $b=7;
my $c=2;
my $d;

$d=($a+$b)*$c;
print "$d\n";
$d=$a+($b*$c);
print $d;