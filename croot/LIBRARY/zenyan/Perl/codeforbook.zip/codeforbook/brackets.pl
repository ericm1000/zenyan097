use strict;

my $str = "abcdefghij";

  if ($str =~ /[fik]/) {
   print "$str\n";}

