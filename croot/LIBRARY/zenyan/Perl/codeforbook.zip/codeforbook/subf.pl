use strict;

my $i=10;



sub mysub 
{
  $i = "ten";
  return $i;
}

print $i = &mysub ($i);

