use strict;

my $x;

#seconds since 1 jan 1970
$x = time;
print "$x\n";
$x = localtime;
print "$x\n";
$x = gmtime;
print "$x\n";


