use strict;

open ("F", "looplast.pl") or die print "$!\n";

while (<F>)
{
  next if $_ =~ /use.*/;
  next if $_ =~ /while.*/;
  print;
}


