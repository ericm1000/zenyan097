use strict;

my @arr = ("me", "meet", "meat", "meaning", "melvin");
my $i;
print "Match - mea: with the asterisk\n";

for ($i=0;$i<5;$i++) {
  if (@arr[$i] =~ /mea*/) {
   print "@arr[$i]\n";}
}

print "\n";
print "Now the plus\n";
print "\n";

for ($i=0;$i<5;$i++) {
  if (@arr[$i] =~ /mea+/) {
   print "@arr[$i]\n";}
}
