use strict;

# Integer Comparison operators
# >, >=, <, <=, ==, !=, <=>


my $x = 5; 
my $y = 10;
my $z = 5;
my $ret;

print "x=5 y=10 z=5 \n";

$ret = $x < $y;
print "$x < $y is $ret\n";

$ret = $x > $y;
print "$x > $y is $ret\n";

$ret = $x >= $z;
print "$x >= $z is $ret\n";

$ret = $x <= $z;
print "$x <= $z is $ret\n";

#equals operator ==
$ret = $x == $y;
print "$x == $y is $ret\n";

$ret = $x == $z;
print "$x == $z is $ret\n";

#not equals operator !=
$ret = $x != $y;
print "$x != $y is $ret\n";

$ret = $x != $z;
print "$x != $z is $ret\n";

$ret = $x <=> $y;
print "$x <=> $y is $ret\n";

#integer comparison operator <=>
$ret = $x <=> $z;
print "$x <=> $z is $ret\n";