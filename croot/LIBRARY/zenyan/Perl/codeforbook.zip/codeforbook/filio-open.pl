use strict;
# file IO

# Syntax: open (<"FILVAR"> , <"filespec">);
#   read: (default)
#  write: >open (<"FILVAR"> , <"filespec">);
# append: >>open (<"FILVAR"> , <"filespec">);

open ("FIL", "filio-open.pl") or die ("can't open file");
my @input = <FIL>;
print @input;



