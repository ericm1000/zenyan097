use strict;
# if's can be nested
my $str = "Goodbye";
my $v = "T";
if ($str) 
{
 if ($v eq "T") 
 {
  $str = "Hello";
 }
  my $flg = "Y";
  if ($flg eq= "Y") 
  {
   $flg = "N";
  }
 print ($flg, " ", $str);
}


