use strict;

# CHOP 
# removes the last character from a scalar value
my $wrd1 = "Goodbye ";

print $wrd1;
print "\n\n";

print "Using Chop on a word";
print "\n";
print "---------------------";
print "\n";

## Using chop on a word
chop $wrd1;
print $wrd1;
print "\n";

chop $wrd1;
print $wrd1;
print "\n";
print "\n";

$wrd1 = "Goodbye";

# CHOMP
# Checks to see if the last character of a string or list of strings matches the input line # separator. If it does chomp removes them.

## Using chomp 

my $wrd3 = "Goodbye";
if ($wrd1 eq $wrd3) {
    print "match\n";
} else { print "no match\n"; }

my $wrd2 = " ";
chomp ($wrd2);
if ($wrd1 eq $wrd3) {
    print "match\n";
} else { print "no match\n"; }


print "type Goodbye and press enter: ";
$wrd2 = <stdin>;

if ($wrd1 eq $wrd2) {
    print "match\n";
} else { print "no match\n"; }

chomp ($wrd2);
if ($wrd1 eq $wrd2) {
    print "match\n";
} else { print "no match\n"; }

$wrd1 = "Goodbye "; # we add a space
if ($wrd1 eq $wrd2) {
    print "match\n";
} else { print "no match\n"; }

chomp ($wrd2);
if ($wrd1 eq $wrd2) {
    print "match\n";
} else { print "no match\n"; }




