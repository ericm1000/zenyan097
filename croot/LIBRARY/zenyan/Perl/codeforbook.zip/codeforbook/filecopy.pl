#F# filecopy.pl
#A# Eric Matthews
#V# n/a
#P# Copy/Move a file
#U# Education, foundation

use File::Copy;

copy("filecopy.pl","filecopy2.pl");  
move("filecopy2.pl","temp");  #assumes subdir named temp

#K# copy a file, system administration