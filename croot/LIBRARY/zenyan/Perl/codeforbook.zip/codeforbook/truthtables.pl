use strict;
my $t=1;
my $f=0;

my $bool;

print ("Perl Truth Tables","\n");
$bool = ($t || $t);
print ("$t || $t = ",$bool,"\n");
$bool = ($f || $t);
print ("$f || $t = ",$bool,"\n");
$bool = ($t || $f);
print ("$t || $f = ",$bool,"\n");
$bool = ($f || $f);
print ("$f || $f = ",$bool,"\n\n");

$bool = ($t && $t);
print ("$t && $t = ",$bool,"\n");
$bool = ($f && $t);
print ("$f && $t = ",$bool,"\n");
$bool = ($t && $f);
print ("$t && $f = ",$bool,"\n");
$bool = ($f && $f);
print ("$f && $f = ",$bool,"\n\n");

$bool = ($t xor $t);
print ("$t xor $t = ",$bool,"\n");
$bool = ($f xor $t);
print ("$f xor $t = ",$bool,"\n");
$bool = ($t xor $f);
print ("$t xor $f = ",$bool,"\n");
$bool = ($f xor $f);
print ("$f xor $f = ",$bool,"\n\n");

$bool = (!$t);
print ("!$t = ",$bool,"\n\n");
$bool = (!$f);
print ("!$f = ",$bool,"\n\n");



