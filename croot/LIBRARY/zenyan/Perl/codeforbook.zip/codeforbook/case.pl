use strict;

print "enter a sentence\n";
my $str = <STDIN>;
print "\U$str\n";
print "\L$str\n";

