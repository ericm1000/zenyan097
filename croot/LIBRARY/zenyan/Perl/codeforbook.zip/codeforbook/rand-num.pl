use strict;
my $n = rand;
print "$n\n";

$n = rand(10);
print "$n\n";


