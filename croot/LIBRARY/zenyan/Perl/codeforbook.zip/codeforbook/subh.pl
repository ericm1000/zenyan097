use strict;
my $i = 0;

&mysub($i);

sub mysub
{
  if ($i <= 5)
  {
   print "$i\n";
   $i++;
   &mysub
  }
}

