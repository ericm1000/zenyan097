use strict;

# file IO
open (STDIN, "filio-open.pl") or die ("can't open file");
my $cnt=0;

while (<>) 
{
 print;
 $cnt++;
}

print "# lines to eof: $cnt";



