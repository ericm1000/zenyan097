use strict;
#Note we only make it to Y
my $str = "A";
my $i;
while ($str lt "Z") {
	print $str;
	$str++;
}

print ("\n\n");

#Note the flaky output
$str = "A";
while ($str le "Z") {
	print $str;
	$str++;
}

print ("\n\n");

#Note we get all 26
$str = "a";
$i = 1;
while ($i <= 26) {
	print $str;
	$i++;
	$str++;
}

print ("\n\n");

#Note we get all 26
$str = "A";
$i = 1;
while ($i <= 26) {
	print $str;
	$i++;
	$str++;
}