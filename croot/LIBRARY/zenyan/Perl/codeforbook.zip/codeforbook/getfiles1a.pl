# This script will start at the main directory, and work through
# all the subdirectories. It will create a file in each directory
# named "list_of_files.txt". The file attributes are set so this file
# will be replaced each time the script is run.

# This is a fairly complex script in the respect that it parses an 
# unbalanced tree structure. Such a structure that can vary in an 
# almost infinite combination is impractical to write using conventional
# loops. The power of recursion (a subroutine that calls itself) is 
# demonstrated in this example. The concept behind this script could be
# easily adapted to build an inheritance tree for OOP languages that implements
# either single or multiple inheritance. I wrote this script because I did
# not see anything in the public domain to accomplish this task. I did not use
# any WIN32 extensions as I wanted the essence of this to remain somewhat 
# platform independent.

# note, in this script each directory in the tree gets a file named 
# "list_of_files.txt". I did this for a number of reasons. For example, 
# it would not be hard to modify this script to write a program that 
# monitors and reports expansion or contraction of a directory. For example,
# you install a new program and want to produce a list of the new files.

# If you understand this script you will see many ways to further abstract
# the code to handle various other possibilities desired in working with
# directories and files. Unfortunatley with abstraction comes a greater
# amount of effort and time. Time I do not have much of at the moment. Feel free
# to copy and modify this script to meet your specific needs.

# One final note, shame on me, I did not add any error handling with respect
# to the command line arguments. If you make a mistake running the script you
# can get a 'out of memory' error. To avoid this make sure your path ends in a
# slash as the example provided below.

# Example Command Line:  >perl getfiles1a.pl c:\educdoc\code\javascript\

# WARNING!!!! If you run this script at the root directory you need to understand
#             that it will create the file "list_of_files.txt" in EVERY SINGLE
#             subdirectory! I did not write the script with the intent that someone
#             would actually want to do this, so unless you want to write another
#             script to find and delete the thousands of these files that could get
#             created exercise good judgement.

use strict;
my $cwd = $ARGV[0];
my $dirf = "list_of_files.txt";

print ("created a list of files for each directory and subdirectory","\n");
print ("starting at directory ", $cwd,"\n");
print ("file is named ",$dirf,"\n");

&scan_parent;

sub scan_parent
{
 my @proc_dir;
 my $proc_dir=0;
 my @arr;
 my $arr=0;
 my $i=0;
 my @proc_files;

 chdir $cwd;
 opendir (cDir, '.');
 # get list of all files and subdirectories
 @arr = (readdir(cDir));
 # call sub to narrow list to subdirs only, pass to dir array 
 @proc_dir = &get_subdirs(@arr);
 $proc_dir = @proc_dir; # size of array
 # call sub to narrow list to files only, pass to files array 
 @proc_files = &get_files(@arr);
 closedir cDir;

 # loop to process our subdirectories 
   for ($i=0; $i<$proc_dir; $i++)
   {
    $cwd = $proc_dir[$i];
    # call me (recursion) to continue processing tree
    &scan_parent;
   }
}

sub get_subdirs
{
  my $i=0;
  my $ia=0;
  my @tmp_dir;
  my @tmp_path_dir;
  my $sZ=0;
  $sZ = @_;

  for ($i=0; $i < $sZ; $i++)
  {
         # -d is arg specifiying a directory
     if (-d ($_[$i]) )  
     {
      if ($_[$i] ne "." & $_[$i] ne "..")
      {
       $tmp_dir[$ia] = ($cwd . $_[$i] . "\\");
       $ia++;
      }
     }
  }
  @_ = @tmp_dir;
}

sub get_files
{
  my $i=0;
  my $ia=0;
  my @tmp_dir;
  my @tmp_path_dir;
  my $sZ=0;
  $sZ = @_;

  open ("f", ">$dirf");
  for ($i=0; $i < $sZ; $i++)
  {
         # -f is arg specifiying a file
     if (-f ($_[$i]) )  
     {
      if ($_[$i] ne "." & $_[$i] ne "..")
      {
       $tmp_dir[$ia] = ($cwd . $_[$i]);
       print f ($tmp_dir[$ia],"\n");
       $ia++;
      } 
     }
  }
  close "f";
  @_ = @tmp_dir;
}


# still has some warnings related to scope. Need to figure these out and correct.

