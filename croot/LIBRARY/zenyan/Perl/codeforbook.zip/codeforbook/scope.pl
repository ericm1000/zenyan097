use strict;
my $i=7;

&mysub;

sub mysub {
   my $i=9;
   print ("sub \$i: ",$i,"\n");
}

   print ("global \$i: ",$i);


