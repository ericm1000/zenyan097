use strict;

my $a=0;
my $b=10;
my $c=8;

sub mysub 
{
  $a = ($b * $c);
  return $a;
}
#call mysub
$a = &mysub ($b,$c);
print "$a\n";

# the above example works fine but does defeat the 
# containment principle of a subroutine by acting on
# a global variable. 

sub mysub2 
{
  my $z=0;
  $z = ($b * $c);
  return $z;
}
#call mysub2
$a = &mysub2 ($b,$c);
print $a;