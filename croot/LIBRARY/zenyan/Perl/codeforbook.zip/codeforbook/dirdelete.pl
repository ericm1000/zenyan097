#F# dirdelete.pl
#A# Eric Matthews
#V# n/a
#P# Delete an empty directory
#U# Education, foundation

#delete a directory
rmdir "d:/aaatestperl/keep/tempbu";
#Note this command will not work if directory is not empty



#K# delete an empty directory, system administration