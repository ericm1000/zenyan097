use strict;

# create empty array
my @arr = (1,2,3,4,5,6);
my $arr = @arr;

unshift (@arr, 'where am I?');

print @arr[0];
