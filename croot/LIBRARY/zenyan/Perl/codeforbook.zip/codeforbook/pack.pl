use strict;
my $i;
my $nbr;
for ($i=0;$i<=255;$i++) {
     print ($i,":",pack("CCC", $i));
}


