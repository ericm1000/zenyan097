#F# filerename.pl
#A# Eric Matthews
#V# n/a
#P# Rename a file
#U# Education, foundation

#rename a file
rename "filecopy2.pl","filecopy2.trash";

my $timedel = time;
rename "filecopy2.trash","filecopy2$timedel.trash";

#K# rename a file, system administration