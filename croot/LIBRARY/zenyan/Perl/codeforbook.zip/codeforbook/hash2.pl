use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);


print $hsh{lastname};

