#F# bv1a.pl
#A# Eric Matthews
#V# n/a
#P# Change input record separator
#U# Education, foundation

use strict;

my @arr=qw(a b c d f);
$" = " :-) ";

print "@arr";

#K# Change input record seperator, array