use strict;
my $i;
my @arr = ("a".."z");
for ($i = 1; $i <= @arr; $i++)
{
print $i;
print "@arr[$i-1] ";
}
