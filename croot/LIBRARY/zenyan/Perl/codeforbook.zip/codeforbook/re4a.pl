use strict;
my $str="zzyz";

 print("Regex: (.*)\n");

if ($str =~ /(z*)/)
{
 print("\$1 is $1\n");
}

 print("\nRegex: (z(z(z(z(z?)?)?)?)?)\n");

if ($str =~ /(z(z(z(z(z?)?)?)?)?)/)
{
 print("\$1 is $1\n");
 print("\$2 is $2\n");
 print("\$3 is $3\n");
 print("\$4 is $4\n");
 print("\$5 is $5\n");
}












