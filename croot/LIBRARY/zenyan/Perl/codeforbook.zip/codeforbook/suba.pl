use strict;

&callsub;

sub callsub 
{
   print "subroutine callsub was called\n";
}

