use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

my $key="";
foreach $key (sort keys %hsh)
{
  print $key . "\n"; 
}

