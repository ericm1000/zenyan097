use strict;
my $i;
if (open ("FILX","forloop3.pl")) {
my @arr = <FILX>;
for ($i = 1; $i <= @arr; $i++)
{
print "$i  ";
print @arr[$i-1];
}
}