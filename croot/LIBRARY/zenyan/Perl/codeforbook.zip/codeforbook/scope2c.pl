use strict;
&mysub;
my $i = 12;
&mysub2;

sub mysub {
   my $i=9;
   print ("sub \$i: ",$i,"\n");
   &mysub2;
}


sub mysub2 {
   print ("sub \$i: ",$i,"\n");
}