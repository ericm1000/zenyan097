use strict;

my %hsh =
(
'batting_avg' , 306 ,
'hits'        , 83  ,
'homeruns'    , 9
);

&mysub(%hsh);

sub mysub
{
  my $key="";
  %hsh = @_;
  foreach $key (keys %hsh)
  {
    print "$key = $hsh{$key}\n";
  }
}

