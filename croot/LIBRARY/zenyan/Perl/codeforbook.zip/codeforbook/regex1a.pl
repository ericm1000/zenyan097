use strict;

my $str="flavour";

if ($str =~ /flavou?r/)
{
  print("$str\n") 
} else { print("no match\n"); }

$str="flavor";

if ($str =~ /flavou?r/)
{
  print("$str\n")
} else { print("no match\n"); }

