use strict;
my $x=<STDIN>;
chomp $x;
if ($x eq "Celtics") 
{
 print "Bob Cousey";
}
 elsif ($x eq "Bulls") 
 {
  print "Michael Jordan";
 }
 elsif ($x eq "Lakers") 
 {
  print "Jerry West";
 }
  else 
  {
   print "Don't know that team";
  }


