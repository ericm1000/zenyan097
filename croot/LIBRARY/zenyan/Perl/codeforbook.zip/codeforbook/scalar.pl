use strict;

my $x = 100;
print "x as number: $x\n";

$x = 100.465;
print "x as number/decimal: $x\n";

$x = "hello";
print "x as word: $x\n";

$x = "
Perl is capable of 
holding a great deal of 
text in a scalar
";
print "x as novel:$x\n";




