use strict;

# sorting an array and rebuilding and array in sorted order

my @x = (1,5,2,30,"a","A","Z","x","This","That");
print "@x\n";

my @y = sort(@x);
print "@y\n";

@x = @y;
print "@x\n";

@y = reverse (@y);
print "@y\n";


