use strict;

# create empty array
my @arr = (1,2,3,4,5);

push (@arr, 'where am I?');

# print 1st element in array
print $arr[5];

