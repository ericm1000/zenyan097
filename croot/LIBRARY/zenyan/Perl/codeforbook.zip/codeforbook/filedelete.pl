#F# filedelete.pl
#A# Eric Matthews
#V# n/a
#P# Delete a file
#U# Education, foundation

#delete a file
unlink "filecopy2.pl";

#delete a group of files
@fildeletelst = <*.bak>;
unlink @fildeletelst;

#K# delete a file, system administration