use strict;
my $x="Hello";
my $y="Goodbye";

if ($x eq "Hello") 
{
	$y=$x;
	print ($y);
}
		



