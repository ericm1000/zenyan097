use strict;

my $w=1;
my $x=5;
my $y=10;
my $z=20;

print ("w=1 ","x=5 ","y=10 ","z=20 ","\n\n");

if ($x < $w or $x < $y) {
 	print ("x < w or x < y","\n");
	print ("at least one condition met","\n\n");
}	else {
	print ("no condition met","\n");
}


if ($x < $w and $x < $y) {
	print ("at least one condition met","\n");
}	else {
 	print ("x < w and x < y","\n");
	print ("no condition met","\n");
}
