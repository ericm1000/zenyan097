use strict;
my $x="Hello";
my $y="Goodbye";

if ($x ne "Hello") 
{
 $y=$x;
 print $y;
}
 else 
 {
  $x=$y;
  print $y;
 }



