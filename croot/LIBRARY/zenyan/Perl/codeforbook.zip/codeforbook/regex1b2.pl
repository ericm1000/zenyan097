use strict;

my @arr=qw(feel felt fertile feat);
my $arr=@arr; # array size
my $i=0;

for ($i=0; $i < $arr; $i++)
{
  if (@arr[$i] =~ /fea+/)
  {
   print("@arr[$i]\n");
  }
}
  


