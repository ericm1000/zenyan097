#warning, danger Will Robinson


$str = "fred";
$str += 1;

# will return 1 in the print statement. using the -w arg when running
# this program will result in a warning that adding 1 to a string is
# a rather silly thing to do.
print $str;