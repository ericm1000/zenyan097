use strict;

my $alpha = "A";
my $alpha2 = "0";

my $bin = unpack("B8", pack("A", $alpha));
print ("$alpha: ",$bin,"\n");

my $bin2 = unpack("B8", pack("A", $alpha2));
print ("$alpha2: ",$bin2,"\n");

print "\n";

my $a="A";
my $i;
my $b;
my $c;
for ($i=0;$i<26;$i++) {
     $b = unpack("B8", pack("a", $a));
     $c = unpack("C", pack("B8", $b));
     print ($a,"  ",$b,"  ","$c","\n");
     $a++;
}