use strict;

# file IO
open ("FIL", "filio-open.pl") or die "can't open file";
my $ln = <FIL>;
my $cnt=0;

while ($ln ne "")  #Note we will recieve a warning if running with -w arg
# this is becuase we are testing for a value in $ln, which will be fine until
# we hit eof. This is not a means you should use
{
 print $ln;
 $ln = <FIL>;
 $cnt++;
}

print "# lines to eof: $cnt";


