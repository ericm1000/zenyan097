use strict;

my $path="d:/temp/";
chdir $path;
opendir (cDir, '.');
my @arr = (readdir(cDir));
 
 

for (my $i=0; $i<@arr; $i++)
{
  if (! -d $arr[$i]) #just get files
  {	
   print "file : " . $arr[$i] . "\n";
  }
  if (-d $arr[$i]) #just get files
  {	
   print "dir : " . $arr[$i] . "\n";
  }
}	