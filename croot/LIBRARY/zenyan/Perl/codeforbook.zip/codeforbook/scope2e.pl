# return
use strict;

print "Enter num1: ";
my $a = <STDIN>;
print "Enter num2: ";
my $b = <STDIN>;


&callsub;

sub callsub {
	print &multiply($a,$b);
}

sub multiply {
	my $x;
	my $y;
	($x, $y) = @_;
	return ($x * $y);
}

 
