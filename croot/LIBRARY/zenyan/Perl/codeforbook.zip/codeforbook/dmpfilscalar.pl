#F# dmpfilscalar.pl
#A# Eric Matthews
#V# n/a
#P# Dump an entire file into a scalar
#U# Education, foundation

use strict;

my $str="";
my $cnt;

#dump a file into a scalar
undef $/;  #default input record seperator from newline to squat
while (<>)
{
 {
  $str = $_;
  ++$cnt;
 }
}

print $str;
print "\nLoop count is...$cnt";	

#K# File IO, input line seperator