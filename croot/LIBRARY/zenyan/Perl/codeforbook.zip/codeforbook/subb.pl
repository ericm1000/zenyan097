use strict;
# global vars
my $a="variable a";
my $b="variable b";
my $c="variable c";

&mysub ($a,$b,$c);

sub mysub 
{
   print "$a\n$b\n$c\n";
}

