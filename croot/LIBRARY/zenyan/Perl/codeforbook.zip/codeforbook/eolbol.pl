use strict;

my $str="Subject is Topic";

print "Regex      pattern to match\n";
print "---------- ----------------\n";
print "/^Subject/ $str\n";

if ($str =~ /^Subject/)
{
  print "match\n";
}

$str="Topic is Subject";

print "/^Subject/ $str\n";

if ($str =~ /^Subject/)
{
  print "match\n";
} else { print "no match\n"; }


print "/Subject\$/ $str\n";

if ($str =~ /Subject$/)
{
  print "match\n";
}

$str="Topic is Subject";

print "/Subject\$/ $str\n";

$str="Subject is Topic";

if ($str =~ /Subject$/)
{
  print "match\n";
} else { print "no match"; }