use strict;

my $i;

#exponentiation
$i=2**15;
print "2**15= $i\n";

#remainder
$i=26%3;
print "26%3= $i\n";


