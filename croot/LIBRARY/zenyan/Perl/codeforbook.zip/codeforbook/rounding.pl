use strict;

my $i = 50.455;
my $ii = 50.4556;
my $iii = 50.456;

$i = sprintf "%.2f",$i;
print $i;

print "\n";

$ii = sprintf "%.2f",$ii;
print $ii;

print "\n";

$iii = sprintf "%.2f",$iii;
print $iii;