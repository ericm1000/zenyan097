use strict;

my $str="hello";

 print("Regex: (.*)\n");

if ($str =~ /(.*)/)
{
 print("\$1 is $1\n");
}

 print("\nRegex: (.(.(.(.(.?)?)?)?)?)\n");

if ($str =~ /(.(.(.(.(.?)?)?)?)?)/)
{
 print("\$1 is $1\n");
 print("\$2 is $2\n");
 print("\$3 is $3\n");
 print("\$4 is $4\n");
 print("\$5 is $5\n");
}












