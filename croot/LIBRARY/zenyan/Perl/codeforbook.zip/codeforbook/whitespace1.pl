#F# whitespace.pl
#A# Eric Matthews
#V# n/a
#P# Get rid of extra white space
#U# Education, foundation

use strict;

my $str="  Subject        is    a   Topic    ";

#trim leading whitespace
$str =~ s/^\s+//;
print $str;
print "\n";

#trim trailing whitespace
$str =~ s/\s+$//;
print $str;
print "\n";

#trim all superfluous whitespace
$str="  Subject        is    a   Topic    ";
$str =~ s/^\s+//;  #bol whitespace
$str =~ s/\s+/ /g; #between words, only one space
$str =~ s/\s+$//;  #eol whitespace
print $str;
print "\n";

#K# regular expressions, pattern matching, whitespace, substitution