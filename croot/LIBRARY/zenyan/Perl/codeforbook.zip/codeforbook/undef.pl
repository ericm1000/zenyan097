use strict;

my $str;

if (defined $str) {
    print "scalar \$str is undefined\n";
}if (!defined $str) {
    print "scalar \$str is undefined\n";
}

my $str2 = "foo";
undef $str2;

if (defined $str2) {
    print "scalar \$str2 is undefined";
}if (!defined $str2) {
    print "scalar \$str2 is undefined";
}