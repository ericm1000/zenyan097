use strict;
# global vars
my $a="global \$a";

&mysub ($a);

sub mysub 
{
# pass call args to our local vars
{
  my $v=10;
  print "$v\n";	
  print "$a\n";	
}

   my $a = @_;
   my $a=4;
   print "$a\n";
}

