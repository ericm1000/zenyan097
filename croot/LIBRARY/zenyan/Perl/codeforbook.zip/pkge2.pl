#F# pkge2.pl
#A# Eric Matthews
#V# n/a
#D# Creating a package of subroutines
#U# Education, intermediate

use strict;
package pkge2;

my $left;
my @even;
my @odd;

sub evenbrs
{
  for (my $i=0; $i<@_; $i++)
  {
    $left = $_[$i]%2;  #% is modulus (remainder) operator	
    unless ($left) #if $left not = 0
    {
     push (@even, $_[$i]);  #then push value into @even
    }
  }
  @even = sort(@even);
  return @even;
}
1;  #return true for sub call


sub oddnbrs
{
  for (my $i=0; $i<@_; $i++)
  {
    $left = $_[$i]%2;  #% is modulus (remainder) operator	
    if ($left) #if $left = 0
    {
     push (@odd, $_[$i]);  #then push value into @odd
    }
  }
  @odd = sort(@odd);
  return @odd;
}
1;  #return true for sub call

#K# package, return array,