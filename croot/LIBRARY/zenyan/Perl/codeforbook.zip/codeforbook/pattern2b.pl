use strict;

#get a search string
print "Enter a string \n";
my $str = <stdin>;
print ("Search string entered: $str","\n");

#get a pattern
print "Enter a pattern \n";
my $pat = <stdin>;

#do not forget chop or chomp with this or it will not work like the 
#previous hardcoded version
chomp ($pat);
print ("Search string entered: $pat","\n");


print ($pat,"\n");
my $rslt = $str =~ /$pat/;
print ("String to search: $str","\n","Did we get a match?: $rslt");
$rslt = $str !~ /$pat/;
print ("\n","Did we NOT get a match?: $rslt");

my @arr = split (/$pat/, $str);
my $cnt = @arr;
print ("\n","Whats left in array: @arr","\n","number of hits: ", ($cnt-1) );





