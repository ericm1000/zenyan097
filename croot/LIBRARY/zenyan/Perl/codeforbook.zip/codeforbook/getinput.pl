use strict;
print "Enter some data:";
my $myvar = <stdin>;
print "You entered...\n $myvar";



