#F# bv1b.pl
#A# Eric Matthews
#V# n/a
#P# Escape meta characters (quotemeta)
#U# Education, foundation

use strict;

my $mStr = "/A-Z+/";
my $str = quotemeta( "/A-Z+/" );  # matches
#my $str = "/A-Z+/" ;             # does not match

if ($mStr =~ /$str/)
{
 print "match\n";
 print "$mStr\n";
 print "$str\n";  
}
else
{
 print "no match\n";
 print "$mStr\n";
 print "$str\n"; 
}

print "\nUnusual indeed say the Mad Hatter\n"

#K# Escape meta characters