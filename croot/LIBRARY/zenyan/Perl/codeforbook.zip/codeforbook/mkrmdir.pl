#F# mkdir.pl
#A# Eric Matthews
#V# n/a
#P# Create/Delete directories
#U# Education, foundation

use File::Path;

#create a dir -- Note, if dir exists this will not execute
#1 echos to console, 0 turns echo off
mkpath("temp",1);
#This is a nondestructive function. If you try to create a directory
#that already exists, it leaves that directory intact.

#remove a dir. This blows the directory away, files and all!
#rmtree("temp",1);

#K# create a directory, remove delete a directory, system administration