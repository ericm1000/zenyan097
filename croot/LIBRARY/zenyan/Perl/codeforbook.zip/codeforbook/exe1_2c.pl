# Week 1
# Exercise 2c
# File: exe1_2c.pl

use strict;

# enhance exe1_1b.pl to also allow the user to search for any string within the file:


