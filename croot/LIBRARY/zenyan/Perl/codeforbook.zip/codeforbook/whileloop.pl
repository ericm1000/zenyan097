use strict;
my $num1;
$num1 = <STDIN>;

while ($num1 <= 50) 
{
$num1 = ($num1 + 1);
print "$num1\n";
}
