use strict;

# create empty array
my @arr = ("two", "one", "ten");

@arr = reverse @arr;

print @arr;


