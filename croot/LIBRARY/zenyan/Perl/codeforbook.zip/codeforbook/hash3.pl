use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

my $title = "Supreme Commander";

$hsh{title} = $title;

print $hsh{firstname};
print " ";
print $hsh{middle_init};
print " ";
print $hsh{lastname};
print ", ";
print $hsh{title};

