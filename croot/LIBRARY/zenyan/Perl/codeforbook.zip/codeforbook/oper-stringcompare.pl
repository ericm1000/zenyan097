use strict;

# String Comparison operators
# lt, gt, le, ge, ne, cmp

my $a = "a";   #ascii 97
my $A = "A";   #ascii 65
my $n1 = "1";  #ascii 49
my $ret;

$ret = $A lt $a;
print "$A lt $a is $ret\n";

$ret = $a lt $A;
print "$a lt $A is $ret\n";

$ret = $n1 lt $a;
print "$n1 lt $a is $ret\n";



