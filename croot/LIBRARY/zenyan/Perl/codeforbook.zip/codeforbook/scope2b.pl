# using MY limits scope to subroutine
#use strict  -commented out for this example
&mysub;

sub mysub {
   my $i=9;
   print ("sub \$i: ",$i,"\n");
}

   print ("\$i outside the sub: ",$i," sorry no can see");


