use strict;

my $str="Course: Perl Programming 201 - for experienced programmers";

if ($str =~ /(.*)([0-9])/)
{
  print $1;
  print "\n";
  print $2;
  print "\n*****************************\n";
}

if ($str =~ /(.*)([0-9]*)/)
{
  print $1;
  print "\n";
  print $2;
  print "\n*****************************\n";
}

if ($str =~ /(.*)([0-9]+)/)
{
  print $1;
  print "\n";
  print $2;
  print "\n*****************************\n";
}

if ($str =~ /(.*)([0-9]?)/)
{
  print $1;
  print "\n";
  print $2;
  print "\n*****************************\n";
}











