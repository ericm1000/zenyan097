use strict;

open ("F", "looplast.pl") or die print "$!\n";

while (<F>)
{
  last if $_ =~ /while.*/;
  print;
}

