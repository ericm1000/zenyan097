use strict;

# create empty array
my @arr = ();

push (@arr, 1);
push (@arr, 2);
push (@arr, 3);
push (@arr, 4);
push (@arr, 5);

# print 1st element in array
print $arr[0];

