use strict;

my $i;

print "dec  oct hex";
print "\n";
print "--------------";
print "\n";
for ($i=1;$i<=16;$i++) {
print ($i," ");
print "   ";
print sprintf "%1o",$i;
print "   ";
print sprintf "%1x",$i;
print "\n";
}


print "\n";
print "\n";

# convert back to decimal
my $io = oct 10;
print "10 octal is $io decimal\n";
my $ih = hex 10;
print "10 hex is $ih decimal\n";