use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);


# exists is used to verify element
if (exists($hsh{middle_init}))
{
 print $hsh{middle_init};
 print "\n"
}
else
{
 print "element does not exist";
}

# delete hash element middle_init
delete $hsh{middle_init};

# is it deleted?
if (exists($hsh{middle_init}))
{
 print $hsh{middle_init};
 print "\n"
}
else
{
 print "element does not exist";
}

# re-add hash element middle_init
$hsh{middle_init} = "";

if (exists($hsh{middle_init}))
{
 print $hsh{middle_init};
 print "\n"
}
else
{
 print "element does not exist";
}