use strict;

# my is a keyword that causes the scalar to be lexically scoped. In English
# (sort of) this makes the scope local. Local in this case means local to this
# Perl program. Within a Perl program we can extend the definition local to also
# be within a subroutine. However, we have not got to this subject yet so we are
# ending the explanation here for the moment.

my $x = 100;
print "x as number: $x\n";
$x = 100.465;
print "x as number/decimal: $x\n";
$x = "hello";
print "x as word: $x\n";
$x = "
Perl is capable of 
holding a great deal of 
text in a scalar
";
print "x as novel:$x\n";




