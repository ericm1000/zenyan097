use strict;

my $str="Course: Foundations of Perl Programming - for experienced programmers";

if ($str =~ /(^Course:) (.*)/)
{
  print $1;
  print "\n";
  print $2;
}

