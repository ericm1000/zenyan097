use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

my $val="";
foreach $val (values %hsh)
{
  print $val . "\n"; 
}
