use strict;

my $str="Course: Foundations of Perl Programming - for experienced programmers";

print ("$str\n");

if ($str =~ /^Course: (.*)/)
{
  print $1;
}

