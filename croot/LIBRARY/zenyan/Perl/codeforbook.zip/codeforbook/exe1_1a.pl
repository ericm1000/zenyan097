# Week 1
# Exercise 1a
# File: exe1_1a.pl
 
# finish this script by looping through the array and 
# returning California to the terminal

use strict;

my @arr=qw(Texas Idaho Washington Arizona Illinois
            Kansas California Louisiana Delaware);


# Note qw saves us from having to use quotes around array elements, and commas to delimit
# elements.

