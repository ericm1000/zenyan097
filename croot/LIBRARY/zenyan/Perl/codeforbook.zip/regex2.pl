use strict;

my @arr=(
         "Operand1=Operand2;"         , 
         "Operand1 =Operand2;"        ,
         "Operand1 = Operand2;"       ,
         "Operand1 =      Operand2;"  ,
         "Operand1 = Operand2;"       ,
         "Operand211 = Operand22;"    ,
         "Operand1 = Operand2  ;"     ,
         "  Operand1 = Operand2  ;"
        );

my $arr=@arr; # array size
my $i=0;

for ($i=0; $i<$arr; $i++)
{
  if ($arr[$i] =~ /Operand[0-9]* *= *Operand[0-9]*;/)
  {
   print("$arr[$i]\n");
  }
}
  


