use strict;

# create empty array
my @arr = ();

push (@arr, 1);
push (@arr, 2);
push (@arr, 3);
push (@arr, 4);
push (@arr, 5);


my $Aval = pop(@arr);

# print last element in array
print $Aval;

print "\n";

print @arr; # NOTE! element we popped is no longer in the array

