use strict;

my @arr = ("a",5,"c");

&mysub (@arr);


sub mysub 
{
my $i=0;
my $sm=@_;
  for ($i=0; $i<$sm; $i++)
  {
    print "$_[$i]\n"
  }
}

