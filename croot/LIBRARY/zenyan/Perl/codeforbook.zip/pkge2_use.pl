#F# pkge2_use.pl
#A# Eric Matthews
#V# n/a
#D# Using a packages of subroutines
#U# Education, intermediate

require 'pkge2.pl';
#use pkge2;

use strict;

my @iArr = qw(6 5 1 8 7 4 3 9 2);

#use vars $x;

# call a sub in a package
my @oArr = pkge2::evenbrs(@iArr);
print "@oArr ";

@oArr = pkge2::oddnbrs(@iArr);
print "\n@oArr ";

#K# package, return array, passing parameters