use strict;

# Assignment Operators
# =
# +=
# --=
# *=
# /=
# %=
# **=

my $val = 5;
print "starting value is 5\n";

$val += 5;
print "val += 5 $val\n";

$val -= 5;
print "val -= 5 $val\n";

$val *= 5;
print "val *= 5 $val\n";

$val /= 5;
print "val /= 5 $val\n";

$val **= 5;
print "val **= 5 $val\n";

$val %= 5;
print "val %= 5 $val\n";
