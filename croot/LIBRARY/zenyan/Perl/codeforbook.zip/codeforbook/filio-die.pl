use strict;

open ("F", "nofile.txt")  or die 
                          (
                           print "cannot open file\n" 
                           . # concatenate with
                           $! # standard error variable
                           );

open ("F", "nofile.txt")  or die ($!);




