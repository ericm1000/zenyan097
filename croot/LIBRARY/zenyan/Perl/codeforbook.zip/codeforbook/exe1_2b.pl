# Week 1
# Exercise 2b
# File: exe1_2b.pl

use strict;

# enhance exe1_2a.pl to offer the user a menu that lets them select the following:
# - list of Cobol programs
# - list of Scobol programs
# - list entire contents of index.txt
# ...the program only needs to execute once (you do not need to write the
#    program until the user wants to exit

