#F# bv1a.pl
#A# Eric Matthews
#V# n/a
#P# Using backtick on the Guardian OS
#U# Education, foundation

###NOTE: This only works on NonStop Guardian OS
use strict;
use backtick;

chomp $ARGV[0];
my $str = $ARGV[0];

open (STDOUT, ">results") or die $!;
my $ar = backtick ($str);
foreach (@{$ar}) {print "$_\n"; }
close STDOUT;

# examples
# "perl -w bt2 "fup info t3data.* where relative"
# "enform/in epdate1/"

#K# run tacl command, Guardian, TACL