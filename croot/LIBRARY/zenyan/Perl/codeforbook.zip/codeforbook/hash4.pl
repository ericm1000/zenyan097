use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

delete $hsh{middle_init};

if (exists($hsh{middle_init}))
{
 print "key exists";
}
else
{
 print "key does not exist";
}


