use strict;

my $str = "This is a rope";

if ($str =~ /(.*)(a)(.*)/)
{
print "$1\n";
print "$2\n";
print "$3\n";
}