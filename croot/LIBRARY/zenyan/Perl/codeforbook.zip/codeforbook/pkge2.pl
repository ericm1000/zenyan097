package pkge2;


# constructor
BEGIN
{
 print "enter some data: ";
}

sub mysub
{
  $str = <>;
  print "You entered the string: " . $str;
}
return 1;

# destructor
END
{
 print "G'day";
}
