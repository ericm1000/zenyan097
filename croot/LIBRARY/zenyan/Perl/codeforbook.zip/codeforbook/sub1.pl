use strict;
# global vars
my $a=1;
my $b=2;
my $c=3;

# program flow
 &mysub;
 &mysub2 ($a,$b,$c);
 &mysub3 ($a,$b,$c);
 print ($a,"\n");
 print ($b,"\n");
 print ($c,"\n");


# subroutines
sub mysub {
# note our sub has scope to the global variables
           print "$a$b$c\n";
}

sub mysub2 {
# pass call args to our local vars
            my ($a,$b,$c) = @_;

# so which $a are we referring to?
            my $a=4;
            print "$a\n";
# ...and how can we access the global vars
           my $a = $c;
           my $b = $c;
           my $c = $c;
           print "$a$b$c\n";
}

sub mysub3 {
            my $a=10;
            my $b=20;
            my $c=30;
            print ("$a ","$b ","$c ","\n");
}


