use strict;

my @arr=(
         "HELLO"         , 
         "57"            ,
         "Goodbye"       ,
         "Turk82"        ,
         "I am 4 you"    ,
         "Whatever"      ,
         "xyz12xyz"      ,
         "I is a "      
        );

my $arr=@arr; 
my $i=0;

for ($i=0; $i<$arr; $i++)
{
  if (@arr[$i] =~ /\b[^0-9]\b/ )
#  if (@arr[$i] =~ /\b[^0-9]+\b/ )
  {
   print("@arr[$i]\n");
  }
}
  
