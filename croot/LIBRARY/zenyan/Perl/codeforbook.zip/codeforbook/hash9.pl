use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

my %swap = reverse %hsh;

my $key="";
foreach $key (keys %swap)
{
  print "$key => $swap{$key}" . "\n";
}