# Week 1
# Exercise 2a
# File: exe1_2a.pl

use strict;

# write a program that opens the file "index.txt" and returns a list of all the Cobol
# (not scobol) programs to the console. Make sure you return all of them!


  


