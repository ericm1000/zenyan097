use strict;

my %person = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

my %phone =
(
area_cde => '206',
exchange => '466',
extension => '1515',
);

my %person_phone = (%person, %phone);

my $key="";
my $val="";
while (($key, $val) = each(%person_phone))
{
  print "$key => $val\n";
}


