use strict;
#can use hex

my $i=0xE;
print "14 =  $i\n";




