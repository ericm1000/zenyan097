use strict;

my @arr=(
         "Operand1=Operand2;"         , 
         "Operand1 =Operand;"         ,
         "\$foo = 32;"                , # note: escape character is needed 
         "Operand1 =      Operand2;"  ,
         "Operand1 = Operand2;"       ,
         "Operand211 = Operand22;"    ,
         "Operand1 = Operand2  ;"     , # note: escape character is needed 
         "  \@arr = qw(1 2 3)  ;  "
        );

my $arr=@arr; # array size
my $i=0;

for ($i=0; $i<$arr; $i++)
{
  if (@arr[$i] =~ / *.+ *= *.+ *;/)
  {
   print("@arr[$i]\n");
  }
}
  


