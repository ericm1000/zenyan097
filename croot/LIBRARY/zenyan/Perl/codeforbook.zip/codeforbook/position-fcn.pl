#F# position-fcn.pl
#A# Eric Matthews
#V# n/a
#P# Find position of entity
#U# Education, foundation

use strict;

$_ = " hello world. goodbye world .  wrap to";
my @arr = ();
my $i = 0;

while (/.\./g)
    {
     ++$i;
     print "periods at position ". pos() . "\n";
    }

#K# position function, regular expression, pattern matching