use strict;

# open file we want to copy
open ("FIL1", "FILE-for-filio-write.txt") or die ("can't open file");

# open file to create and receive the data we wish to copy
open (STDOUT, ">Newfile.txt") or die ("can't open file");


while (<FIL1>)
{
 print STDOUT;
}



 