use strict;

&sub_out;

sub sub_out
{
my $str = "call inner sub";

  sub sub_in
  {
   my $strI = $str;
   print $strI;
  }

&sub_in($str);

}

