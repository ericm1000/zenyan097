use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

my $key="";
foreach $key (keys %hsh)
{
  print $key . "\n"; 
}

