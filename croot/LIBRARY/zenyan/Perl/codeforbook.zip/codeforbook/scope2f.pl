use strict;  

&mysub;

sub mysub {
   my $i=9;
   print ("sub \$i: ",$i,"\n");
   &mysub2($i);
}


sub mysub2 {
   my $x = shift(@_);
   print ("sub \$x: ",$x,"\n");
}

# we are calling mysub2 again to demonstrate that the 
# life of a locally scoped var is for the duration of
# the call.
&mysub2;