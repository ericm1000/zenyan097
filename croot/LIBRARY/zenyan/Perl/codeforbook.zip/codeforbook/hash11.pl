use strict;

my %hsh = 
(
firstname => 'John',
middle_init => 'H.',
lastname => 'Smith',
);

my $val="";
foreach $val (sort values %hsh)
{
  print $val . "\n"; 
}

