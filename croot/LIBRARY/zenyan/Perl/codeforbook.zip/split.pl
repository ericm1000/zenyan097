###NOTE: only use the #X# tags if you want Perl program picked up and indexed
#F# split.pl
#A# Eric Matthews
#V# na
#D# Split
#U# Education, foundation

use strict;

my $str = "this is the    way to   Ed and Fred and Teds  place";
my @arr = split (/ /, $str);
my $cnt = @arr;
print "$cnt\n";

my $str1 = "this is the one? This is two! This is three.";
my @arr1 = split (/[\.\!\?]/, $str1);
my $cnt1 = @arr1;
print "@arr1\n";
print "$cnt1\n";

#K# split