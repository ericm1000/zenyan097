# a compelling reason to use MY in variable declaration

&mysub;

sub mysub {
   $i=9;
   print ("sub \$i: ",$i,"\n");
}

   print ("\$i outside the sub: ",$i," hmmmmm");


