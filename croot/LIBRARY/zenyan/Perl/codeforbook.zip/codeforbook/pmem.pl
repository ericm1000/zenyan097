use strict;

my $str = "This is a rope";

print "\$1 gives nothing up because it does not have to\n";
print "----------------------------------------------------------\n";

if ($str =~ /(.*)(.*)(.*)(.*)/)
{
print "$1\n";
print "$2\n";
print "$3\n";
print "$4\n";
}

print "\$1,2,3 only give up a single charactor from their stash\n";
print "----------------------------------------------------------\n";

if ($str =~ /(.+)(.+)(.+)(.+)/)
{
print "$1\n";
print "$2\n";
print "$3\n";
print "$4\n";
}

print "\$1,2,3 themselves give up nothing, the stash is $str\n";
print "----------------------------------------------------------\n";

if ($str =~ /(.?)(.?)(.?)(.?)/)
{
print "$1\n";
print "$2\n";
print "$3\n";
print "$4\n";
}

