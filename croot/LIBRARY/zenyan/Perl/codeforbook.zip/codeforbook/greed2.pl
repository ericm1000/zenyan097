use strict;

my $str = "mandy";

if ($str =~ /\w[re]/)
{
 print "/\\w[re]/ matches\n";
}
else
{
 print "/\\w[re]/ does not match\n";
}

if ($str =~ /\w[re]+/)
{
 print "/\\w[re]+/ matches\n";
}
else
{
 print "/\\w[re]+/ does not match\n";
}

if ($str =~ /\w[re]?/)
{
 print "/\\w[re]?/ matches\n";
}
else
{
 print "/\\w[re]?/ does not match\n";
}


if ($str =~ /\w[re]*/)
{
 print "/\\w[re]*/ matches\n";
}
else
{
 print "/\\w[re]*/ does not match\n";
}