require 'pkge2.pl';

use strict;

my $x;
my $y;

use vars ($x);

# call a sub in a package
pkge2::mysub();

# reference a variable in a package
print "variable $str from package, value is -" . $pkge2::str . "\n";
# note nothing happens here. We do not have access to variables in a package
# that are declared with my. This gives our package a level of encapsulation




