use strict;

my $i=0;

sub mysub 
{
  ++$i;
  print "$i\n";
}

&mysub ($i);
&mysub ($i);
&mysub ($i);
&mysub ($i);