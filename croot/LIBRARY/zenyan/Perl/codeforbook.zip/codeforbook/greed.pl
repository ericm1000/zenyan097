use strict;

my $str = "freds";

if ($str =~ /\w[re]/)
{
 print "/\\w[re]/ matches\n";
}
else
{
 print "/\\w[re]/ does not match\n";
}

if ($str =~ /\w[re]+/)
{
 print "/\\w[re]+/ matches\n";
}
else
{
 print "/\\w[re]+/ does not match\n";
}

if ($str =~ /\w[re]?/)
{
 print "/\\w[re]?/ matches\n";
}
else
{
 print "/\\w[re]?/ does not match\n";
}


if ($str =~ /\w[re]*/)
{
 print "/\\w[re]*/ matches\n";
}
else
{
 print "/\\w[re]*/ does not match\n";
}