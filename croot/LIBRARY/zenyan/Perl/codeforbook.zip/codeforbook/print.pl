use strict;

#Print a string
print "Print this string\n";

#Print a couple of strings with a line break in between
print "Print this string\nPrint another string\n";

#Print a string and a variable
my $myvar = "Hello";
print "Print this string: $myvar";




