################################################################################
#
# ScanDirs.pl
#
# Ladd Lindsay
#
# This program scans through the directory specified on the command line and
# through all of the subdirectories as well, building a list of the regular 
# files.
#
use strict;

my @dirProcessList;
my @FileList;
################################################################################
#
# Main Program
#
# This program reads through a specified directory, then begins reading all of 
# the subdirectories and building a list of files.
#
# Note: Depending on how you want to process the files, the @FileList loop could
# 	be moved outside of the @dirProcessList loop to just process all the files
#	after they've all been identified.  Also, you could preserve the directory
#	list by moving through the array instead of shifting them off the array.
#
my $strTemp;
my $cwd = $ARGV[0];

#		If the directory specified didn't already end with a \, add it now
#		Push the directory name onto the list of directories to process
#		Process each directory name until there are no more
#		Print list of any files found in this subdirectory
#
	$cwd = $cwd . "\\" if ($cwd !~ /\\$/);
	push(@dirProcessList, $cwd);
	while (@dirProcessList > 0)
	{
		$strTemp = shift(@dirProcessList);
		print "Process Directory: $strTemp\n";
		scan_Directory($strTemp);

		while (@FileList)
		{
			$strTemp = shift(@FileList);
			print "$strTemp\n";
		}

	}

################################################################################
#
# Subroutines
#
################################################################################
#
# scan_Directory
#
# Changes to the directory specified on the command line and reads the entire
# directory.  Adds any subdirectories to the directory list array and adds any
# regular files found to the File List array.
#
#
sub scan_Directory
{
    my @arr;
    my $i=0;
    my $k=0;

    my $dir = $_[0];
    

# read the specified directory and load into @arr
    chdir $dir;
    opendir (cDir, '.');
    @arr = (readdir(cDir));
    closedir cDir;


# loop through the list of files and push directories and files onto arrays
    $i = @arr;
    $k = 0;
    while ($k < $i)
    {
    	if ($arr[$k] !~ /^\.\.?$/)
    	{
        	if (-d ($arr[$k]) )  		# is it a directory?
        	{
 			push(@dirProcessList, $dir . $arr[$k] . "\\")
	        }
	        elsif (-f ($arr[$k]) )		# is it a regular file?
	        {
	        	push(@FileList,$dir . $arr[$k])
	        }
	        
    	}
	 $k++;
    }
} # end sub

