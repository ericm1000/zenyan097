use strict;

# file IO
my $f = <STDIN>;

open ("FIL", "$f") or die ("can't open file");
my $ln = <FIL>;

while (<FIL>) 
{
 print $_;
}


