use strict;

# Assigning a character or string to a scalar
my $str = "this is a string";
print ("\$str: ",$str,"\n");

# Assigning a scalar to a scalar
my $str2 = $str;
print ("\$str2: ",$str,"\n");

# Assigning two scalar to a scalar using the concatenation operator
my $str3 = $str .= $str2;
print ("\$str3: ",$str3,"\n");
my $strA = "A";
$str3 = $strA .= $strA;
print ("\$strA: ",$strA,"\n");
print ("\$str3: ",$str3,"\n");

# Assigning a number to a scalar
my $str4 = 10;
print ("\$str4: ",$str4,"\n");

# Assigning the results of an expression to a scalar
my $str5 = (5 * ($str4 + 4));
print ("\$str5: ",$str5,"\n");
        # Parenthesis are resolved inner to outer.

#Indirection
my $str6;
my $str7;
$str6 = $str7 = "hello";
print ("\$str6: ",$str6,"\n");
