use strict;
my $x = "Baseball";
my $y;
my $z; 
$y = $x;
printf ("x is:  $x\n");

if ($x eq $y) {
    $z = "True";
}
printf ("z is:  $z\n");


$z = (8 + 4);
# Note below is not ok because this is not an equals sign
#(8 + 4) = $z
printf ("z is:  $z\n");


