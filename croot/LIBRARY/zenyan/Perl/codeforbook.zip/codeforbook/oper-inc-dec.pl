use strict;
# Increment/Decrement Operator

# note number is assigned before loop execution
my $v = 0;
while (++$v <= 10) {
 print "$v\n";
}

# note number is assigned after loop execution, hence we get to 11
$v = 0;
while ($v++ <= 10) {
 print "$v\n";
}

$v = 0;
while (--$v >= -10) {
 print "$v\n";
}

$v = 0;
while ($v-- >= -10) {
 print "$v\n";
}