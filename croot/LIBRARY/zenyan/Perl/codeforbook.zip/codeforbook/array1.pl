use strict;

my $i;
my @arr = ("one","two","three","four","five");

my $lngth = @arr;
print ($lngth,"\n");

# Do not put parenthesis around the variable or the first item in array will be returned.
($lngth) = @arr;
print ($lngth,"\n\n");

# Accessing an array item by subscript
# accessing an element in an array, note 0 based
print ($arr[2],"\n");

# Finding an array element
for ($i=0; $i<@arr; $i++) {
  if ($arr[$i] eq "three") {
  print ($arr[$i],"\n");
  print ("element ",$i," in the array","\n"); 
  }
}


# Assigning and array to an array
my @arr2;
@arr2 = @arr;
print ("elements in arr2 follow: ","\n");
print ("@arr2 ");



